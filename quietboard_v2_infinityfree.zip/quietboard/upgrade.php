<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['admin_id'])) { http_response_code(403); exit('Log in as an administrator on index.php first, then visit this page.'); }
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    try { $pdo->exec('ALTER TABLE threads ADD COLUMN locked TINYINT(1) NOT NULL DEFAULT 0'); $message='Upgrade complete: thread locking is now enabled.'; }
    catch (PDOException $e) {
        // MySQL duplicate-column error means this migration has already run.
        if (str_contains(strtolower($e->getMessage()), 'duplicate column') || (string)$e->getCode()==='42S21') $message='No database change needed: thread locking is already enabled.';
        else throw $e;
    }
} catch (Throwable $e) { http_response_code(500); exit('Upgrade failed. Back up your database and check the MySQL error: '.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8')); }
?><!doctype html><html lang="en"><meta charset="utf-8"><title>QuietBoard upgrade</title><body style="font:16px system-ui;max-width:650px;margin:40px auto;padding:0 16px"><h1><?= htmlspecialchars($message,ENT_QUOTES,'UTF-8') ?></h1><p>Delete <strong>upgrade.php</strong> from htdocs now, then return to <a href="index.php">your board</a>.</p></body></html>
