<?php
// Copy this to config.php, or run installer.php to generate it.
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXXXX_board');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'YOUR_INFINITYFREE_MYSQL_PASSWORD');
define('BOARD_TITLE', 'QuietBoard');
